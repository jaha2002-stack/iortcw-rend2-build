#!/usr/bin/env python3
"""DarkWolf V4 FIRST AND ONLY DIAGNOSTIC RELEASE (universal source-local A/B).
Rebuild exact clean #41019985033 plus accepted V1/V2/V3/V31 and V32 TEST code;
this script installs V4 data-driven diagnostics without global material removal.
Must not be treated as production source without subsequent GPU verification.
"""
import argparse, hashlib, json
from pathlib import Path

MARK = 'DARKWOLF_POINT_V4_AUTOMATIC_FIXTURE_ATTRIBUTION_DIAGNOSTIC_41019985033'
EXPECTED = {
    'tr_local.h': '5d91aa073076ce15b051452a431e81c686d3d064147d0003a49100d73c352f4b',
    'tr_init.c': 'be5ee356ce14b21793d1feead14aefb5bf4f173fde0127ca3c49e33cff9506a0',
    'tr_backend.c': '1aeb916acc639eda4d8d657bd084c46765b5869f23de2e60c909e254ec1eb458',
}
NAMES = (
    ('r_dwPointV4Scan','0','0',0,1,True),
    ('r_dwPointV4Mode','0','CVAR_LATCH',0,3,True),
    ('r_dwPointV4FocusMap','none','CVAR_LATCH',None,None,False),
    ('r_dwPointV4FocusX','0','CVAR_LATCH',-131072,131072,False),
    ('r_dwPointV4FocusY','0','CVAR_LATCH',-131072,131072,False),
    ('r_dwPointV4FocusZ','0','CVAR_LATCH',-131072,131072,False),
    ('r_dwPointV4FocusId1','-1','CVAR_LATCH',-1,500000,True),
    ('r_dwPointV4FocusId2','-1','CVAR_LATCH',-1,500000,True),
    ('r_dwPointV4FocusId3','-1','CVAR_LATCH',-1,500000,True),
    ('r_dwPointV4FocusLinked','0','CVAR_LATCH',0,1,True),
)
def sha(s): return hashlib.sha256(s.encode('utf-8')).hexdigest()
def replace_once(s,a,b,description):
    n=s.count(a)
    assert n==1,(description,n)
    return s.replace(a,b,1)

C_CODE=r'''
/* DARKWOLF_POINT_V4_AUTOMATIC_FIXTURE_ATTRIBUTION_DIAGNOSTIC_41019985033
 * FIRST diagnostic attempt. Scans every ordinary point capture for nearby BSP
 * geometry and a nearby emitter-like BSP surface, records source-unique IDs,
 * materials, 3-D bounds and confidence, and generates a selection CFG.
 * Modes 1..3 temporarily omit ONLY selected surfaces from ONE selected
 * ordinary point-shadow cubemap. All V4 defaults disabled. NEVER production.
 * Material names here are evidence/heuristics ONLY, not global exclusions.
 * No promise of true fixture association without source/object metadata.
 */
#include <stdarg.h>
#define DWV4_MAX_SOURCES 40
#define DWV4_MAX_CANDIDATES 10

typedef struct {
    int id,seenDraws,skippedDraws,linked;
    float nearDist,halfDiag,centerDist,lightDist,score;
    char material[112];
    vec3_t lower, upper;
} dwV4Candidate_t;
typedef struct {
    vec3_t capture;
    float cameraDist;
    int candidateCount;
    int hasEmitter;
    int draws,skips;
    dwV4Candidate_t candidates[DWV4_MAX_CANDIDATES];
} dwV4Source_t;
static dwV4Source_t dwV4Sources[DWV4_MAX_SOURCES];
static int dwV4SourceCount=0, dwV4CurrentSource=-1;
static const world_t *dwV4World=NULL;
static const msurface_t *dwV4WorldSurfaces=NULL;
static int dwV4WorldCount=0, dwV4LastReportFrame=-3000;
static char dwV4Map[MAX_QPATH]="";
static int dwV4OverflowWarned=0,dwV4WarnedNoCandidate=0;

static qboolean DWV4Enabled(void)
{
    return r_dwPointV4Scan && r_dwPointV4Scan->integer==1;
}
static qboolean DWV4OrdinaryPoint(void)
{
    if(!DWV4Enabled() || !tr.world || !tr.world->surfaces)return qfalse;
    if((backEnd.viewParms.flags&(VPF_SHADOWMAP|VPF_DEPTHSHADOW))!=
       (VPF_SHADOWMAP|VPF_DEPTHSHADOW))return qfalse;
    if(backEnd.viewParms.flags&
       (VPF_DLIGHT_WORLD_OCCLUSION|VPF_FIREVOL_SYNTHETIC_SHADOW))return qfalse;
    return qtrue;
}
static float DWV4Dist3(const vec3_t a,const vec3_t b)
{
    float x=a[0]-b[0], y=a[1]-b[1], z=a[2]-b[2];
    return sqrtf(x*x+y*y+z*z);
}
static float DWV4BoxPointDist(const vec3_t p,const cullinfo_t *ci)
{
    int j; float sum=0.0f;
    for(j=0;j<3;j++){
        float d=0.0f;
        if(p[j]<ci->bounds[0][j])d=ci->bounds[0][j]-p[j];
        else if(p[j]>ci->bounds[1][j])d=p[j]-ci->bounds[1][j];
        sum+=d*d;
    }
    return sqrtf(sum);
}
static float DWV4BoxBoxDist(const cullinfo_t *a,const cullinfo_t *b)
{
    float sum=0.0f; int j;
    for(j=0;j<3;j++){
        float d=0;
        if(a->bounds[1][j]<b->bounds[0][j])d=b->bounds[0][j]-a->bounds[1][j];
        else if(b->bounds[1][j]<a->bounds[0][j])d=a->bounds[0][j]-b->bounds[1][j];
        sum+=d*d;
    }
    return sqrtf(sum);
}
static qboolean DWV4EmitterName(const char *shader)
{
    return shader && (strstr(shader,"/lights/")||strstr(shader,"/light")||
           strstr(shader,"_light")||strstr(shader,"/lamp")||
           strstr(shader,"/flame")||strstr(shader,"/fire")||
           strstr(shader,"/glow")||strstr(shader,"/bulb"));
}
static qboolean DWV4DisallowCandidate(const char *name)
{
    return !name || DWV4EmitterName(name) || strstr(name,"sky") ||
           strstr(name,"cloud") || strstr(name,"portal") ||
           strstr(name,"nodraw") || strstr(name,"water") ||
           strstr(name,"flare") || strstr(name,"fog") ||
           strstr(name,"glass") || strstr(name,"decal");
}
static void DWV4EnsureMap(void)
{
    if(!tr.world)return;
    if(dwV4World!=tr.world || dwV4WorldSurfaces!=tr.world->surfaces ||
       dwV4WorldCount!=tr.world->numsurfaces ||
       strcmp(dwV4Map,tr.world->name)!=0)
    {
        dwV4SourceCount=0;dwV4CurrentSource=-1;
        dwV4World=tr.world;dwV4WorldSurfaces=tr.world->surfaces;
        dwV4WorldCount=tr.world->numsurfaces;
        Q_strncpyz(dwV4Map,tr.world->name,sizeof(dwV4Map));
        dwV4LastReportFrame=-3000;
        dwV4OverflowWarned=0;dwV4WarnedNoCandidate=0;
        memset(dwV4Sources,0,sizeof(dwV4Sources));
        ri.Printf(PRINT_ALL,"DW_PS_V4_MAP map=%s bspMain=%d bspTotal=%d mode=%d scan=%d\n",
           tr.world->baseName,tr.world->numWorldSurfaces,tr.world->numsurfaces,
           r_dwPointV4Mode->integer,r_dwPointV4Scan->integer);
    }
}
static void DWV4InsertCandidate(dwV4Source_t *src,const dwV4Candidate_t *c)
{
    int i,pos=src->candidateCount;
    for(i=0;i<src->candidateCount;i++)
       if(c->score>src->candidates[i].score){pos=i;break;}
    if(pos>=DWV4_MAX_CANDIDATES)return;
    if(src->candidateCount<DWV4_MAX_CANDIDATES)src->candidateCount++;
    for(i=src->candidateCount-1;i>pos;i--)
       src->candidates[i]=src->candidates[i-1];
    src->candidates[pos]=*c;
}
static void DWV4ScanSource(dwV4Source_t *src)
{
    int i,j,nEmit=0;
    int emitterIDs[256];
    const int mainCount=tr.world->numWorldSurfaces;
    if(mainCount<1 || mainCount>200000 || mainCount>tr.world->numsurfaces){
        ri.Printf(PRINT_WARNING,"DW_PS_V4_NO_SCAN unreasonable BSP world surface count %d\n",mainCount);
        return;
    }
    /* Emitter-like world surfaces are only spatial clues, not source ownership. */
    for(i=0;i<mainCount;i++){
        msurface_t *m=&tr.world->surfaces[i];
        if(!m->data || !m->shader || !(m->cullinfo.type&CULLINFO_BOX))continue;
        if(!DWV4EmitterName(m->shader->name))continue;
        if(DWV4BoxPointDist(src->capture,&m->cullinfo)>80.0f)continue;
        if(nEmit<256)emitterIDs[nEmit++]=i;
    }
    src->hasEmitter=(nEmit>0);
    for(i=0;i<mainCount;i++){
        msurface_t *m=&tr.world->surfaces[i];
        dwV4Candidate_t c;
        vec3_t center,diff;
        float d,diag,ratio,emitterSeparation=1e6f;
        if(!m->data || !m->shader || !(m->cullinfo.type&CULLINFO_BOX))continue;
        if(DWV4DisallowCandidate(m->shader->name))continue;
        d=DWV4BoxPointDist(src->capture,&m->cullinfo);
        if(d>64.0f)continue;
        for(j=0;j<3;j++){
            diff[j]=m->cullinfo.bounds[1][j]-m->cullinfo.bounds[0][j];
            center[j]=0.5f*(m->cullinfo.bounds[1][j]+m->cullinfo.bounds[0][j]);
        }
        diag=0.5f*VectorLength(diff);
        if(diag<3.0f || diag>80.0f)continue;
        ratio=diag/(DWV4Dist3(center,src->capture)>8.0f?
             DWV4Dist3(center,src->capture):8.0f);
        if(ratio<0.18f)continue;
        for(j=0;j<nEmit;j++){
            float gap=DWV4BoxBoxDist(&m->cullinfo,
                             &tr.world->surfaces[emitterIDs[j]].cullinfo);
            if(gap<emitterSeparation)emitterSeparation=gap;
        }
        memset(&c,0,sizeof(c));
        c.id=i;c.nearDist=d;c.halfDiag=diag;
        c.centerDist=DWV4Dist3(center,src->capture);
        c.lightDist=emitterSeparation;
        c.linked=(d<=32.0f && emitterSeparation<=18.0f)?1:0;
        /* The geometric risk is source-local. The emitter proximity bonus
           helps distinguish a housing from an unrelated nearby wall. */
        c.score=48.0f/(16.0f+d)+2.0f*(ratio<3.0f?ratio:3.0f)+
                (c.linked?5.0f:0.0f);
        Q_strncpyz(c.material,m->shader->name,sizeof(c.material));
        VectorCopy(m->cullinfo.bounds[0],c.lower);
        VectorCopy(m->cullinfo.bounds[1],c.upper);
        DWV4InsertCandidate(src,&c);
    }
}
static void DWV4BeginPass(void)
{
    int i;
    dwV4Source_t *src;
    dwV4CurrentSource=-1;
    if(!DWV4OrdinaryPoint())return;
    DWV4EnsureMap();
    for(i=0;i<dwV4SourceCount;i++)
       if(DWV4Dist3(dwV4Sources[i].capture,backEnd.viewParms.or.origin)<0.2f)
       {dwV4CurrentSource=i;return;}
    if(dwV4SourceCount>=DWV4_MAX_SOURCES){
        if(!dwV4OverflowWarned++)
            ri.Printf(PRINT_WARNING,"DW_PS_V4_SOURCE_OVERFLOW map=%s max=%d; fail open\n",
                      tr.world->baseName,DWV4_MAX_SOURCES);
        return;
    }
    dwV4CurrentSource=dwV4SourceCount++;
    src=&dwV4Sources[dwV4CurrentSource];
    memset(src,0,sizeof(*src));
    VectorCopy(backEnd.viewParms.or.origin,src->capture);
    src->cameraDist=DWV4Dist3(backEnd.refdef.vieworg,src->capture);
    DWV4ScanSource(src);
    ri.Printf(PRINT_ALL,
      "DW_PS_V4_SOURCE map=%s capture=(%.2f %.2f %.2f) cameraDist=%.1f emittersNear=%d candidates=%d firstID=%d firstMaterial=%s firstScore=%.3f firstLinked=%d\n",
      tr.world->baseName,src->capture[0],src->capture[1],src->capture[2],
      src->cameraDist,src->hasEmitter,src->candidateCount,
      src->candidateCount?src->candidates[0].id:-1,
      src->candidateCount?src->candidates[0].material:"(none)",
      src->candidateCount?src->candidates[0].score:0.0f,
      src->candidateCount?src->candidates[0].linked:0);
}
static qboolean DWV4InspectAndMaybeSkip(drawSurf_t *ds)
{
    dwV4Source_t *src;
    int i,entityNum,mode,id=-1,matchedFocus=0,willSkip=0;
    if(!DWV4OrdinaryPoint()||dwV4CurrentSource<0||!ds||!ds->surface)
        return qfalse;
    src=&dwV4Sources[dwV4CurrentSource];
    entityNum=(ds->sort>>QSORT_REFENTITYNUM_SHIFT)&REFENTITYNUM_MASK;
    if(entityNum!=REFENTITYNUM_WORLD)return qfalse;
    src->draws++;
    for(i=0;i<src->candidateCount;i++){
        if(tr.world->surfaces[src->candidates[i].id].data==ds->surface){
            src->candidates[i].seenDraws++;
            id=src->candidates[i].id;
            break;
        }
    }
    mode=r_dwPointV4Mode->integer;
    if(mode==0)return qfalse;
    /* HARD source/map/ID binding generated by the baseline pass itself. */
    if(strcmp(r_dwPointV4FocusMap->string,tr.world->baseName)!=0 ||
       fabsf(src->capture[0]-r_dwPointV4FocusX->value)>0.30f ||
       fabsf(src->capture[1]-r_dwPointV4FocusY->value)>0.30f ||
       fabsf(src->capture[2]-r_dwPointV4FocusZ->value)>0.30f)
        return qfalse;
    matchedFocus=1;
    if(matchedFocus && id>=0){
        if(mode==1 && r_dwPointV4FocusLinked->integer==1 &&
           id==r_dwPointV4FocusId1->integer)willSkip=1;
        else if(mode==2 && id==r_dwPointV4FocusId1->integer)willSkip=1;
        else if(mode==3 && (id==r_dwPointV4FocusId1->integer ||
                 id==r_dwPointV4FocusId2->integer ||
                 id==r_dwPointV4FocusId3->integer))willSkip=1;
    }
    if(willSkip){
        src->skips++; src->candidates[i].skippedDraws++;
        if(src->skips==1)
            ri.Printf(PRINT_ALL,
              "DW_PS_V4_SOURCE_LOCAL_SKIP map=%s mode=%d source=(%.2f %.2f %.2f) id=%d shader=%s linked=%d\n",
              tr.world->baseName,mode,src->capture[0],src->capture[1],
              src->capture[2],id,src->candidates[i].material,
              src->candidates[i].linked);
        return qtrue;
    }
    return qfalse;
}
static void DWV4Append(char **p,size_t *left,const char *fmt,...)
{
    va_list ap;int n;
    if(*left<=1)return;
    va_start(ap,fmt);n=vsnprintf(*p,*left,fmt,ap);va_end(ap);
    if(n<0 || (size_t)n>=*left){*p+=*left-1;*left=1;**p=0;}
    else {*p+=n;*left-=(size_t)n;}
}
static void DWV4SafeString(const char *in,char *out,size_t cap)
{
    size_t i=0;if(!in)in="?";
    while(*in && i+1<cap){unsigned char c=(unsigned char)*in++;
        out[i++]=(c>=32 && c<127 && c!='"' && c!='\\')?(char)c:'_';}
    out[i]=0;
}
static int DWV4BestSource(int *idx1,int *idx2,int *idx3,int *linked)
{
    int i,j,best=-1,bestCandidate=-1;float score=-1e30f;
    if(idx1)*idx1=-1;if(idx2)*idx2=-1;if(idx3)*idx3=-1;
    if(linked)*linked=0;
    for(i=0;i<dwV4SourceCount;i++){
        dwV4Source_t *s=&dwV4Sources[i];
        for(j=0;j<s->candidateCount;j++){
            dwV4Candidate_t *c=&s->candidates[j];
            float camPenalty=s->cameraDist>600.0f?
                  0.002f*(s->cameraDist-600.0f):0;
            float weighted=c->score-camPenalty;
            if(c->seenDraws==0)continue;
            if(weighted>score){score=weighted;best=i;bestCandidate=j;}
        }
    }
    if(best<0)return -1;
    if(idx1)*idx1=dwV4Sources[best].candidates[bestCandidate].id;
    if(linked)*linked=dwV4Sources[best].candidates[bestCandidate].linked;
    if(idx2||idx3){
        int n=0;
        dwV4Source_t *s=&dwV4Sources[best];
        for(j=0;j<s->candidateCount;j++){
            if(j==bestCandidate || s->candidates[j].seenDraws==0)continue;
            if(n==0 && idx2)*idx2=s->candidates[j].id;
            if(n==1 && idx3)*idx3=s->candidates[j].id;
            if(++n>=2)break;
        }
    }
    return best;
}
static void DWV4WriteDiagnostics(void)
{
    char *buf,*out,filename[128],selection[900];
    size_t remaining=512*1024;
    int i,j,mode,best,idx1,idx2,idx3,linked;
    if(!DWV4OrdinaryPoint() || dwV4SourceCount<1)return;
    if(dwV4LastReportFrame>=0 && tr.frameCount-dwV4LastReportFrame<100)return;
    dwV4LastReportFrame=tr.frameCount;
    mode=r_dwPointV4Mode->integer;
    buf=(char*)malloc(remaining);
    if(!buf){ri.Printf(PRINT_WARNING,"DW_PS_V4_REPORT_ALLOC_FAILED\n");return;}
    out=buf;
    best=DWV4BestSource(&idx1,&idx2,&idx3,&linked);
    DWV4Append(&out,&remaining,
       "{\n\"format\":\"DW_POINT_V4_UNIVERSAL_DIAGNOSTIC\",\n"
       "\"map\":\"%s\",\"mode\":%d,\"sourceCount\":%d,"
       "\"selectedSourceIndex\":%d,\"selectedSurfaceIds\":[%d,%d,%d],"
       "\"selectedLinked\":%s,"
       "\"automatedAssociationIsHeuristic\":true,"
       "\"depthPixelOwnershipVerified\":false,"
       "\"suppressionIsSourceLocal\":true,"
       "\"globalMaterialExclusion\":false,"
       "\"allChangesTestOnly\":true,"
       "\"sources\":[\n",
       tr.world->baseName,mode,dwV4SourceCount,best,
       idx1,idx2,idx3,linked?"true":"false");
    for(i=0;i<dwV4SourceCount;i++){
        dwV4Source_t *src=&dwV4Sources[i];
        DWV4Append(&out,&remaining,
           "%s{\"capture\":[%.3f,%.3f,%.3f],\"cameraDistance\":%.2f,"
           "\"hasNearbyEmitterLikeSurface\":%s,\"draws\":%d,\"skippedDraws\":%d,"
           "\"candidates\":[",
           i?",\n":"",src->capture[0],src->capture[1],src->capture[2],
           src->cameraDist,src->hasEmitter?"true":"false",src->draws,src->skips);
        for(j=0;j<src->candidateCount;j++){
            const dwV4Candidate_t *c=&src->candidates[j];char safe[140];
            DWV4SafeString(c->material,safe,sizeof(safe));
            DWV4Append(&out,&remaining,
               "%s{\"id\":%d,\"material\":\"%s\",\"score\":%.4f,"
               "\"distanceToCapture\":%.3f,\"centerDistance\":%.3f,"
               "\"halfDiagonal\":%.3f,\"distanceToEmitterSurface\":%.3f,"
               "\"emitterLinkedHeuristic\":%s,\"seenDraws\":%d,"
               "\"skippedDraws\":%d,\"boundsMin\":[%.2f,%.2f,%.2f],"
               "\"boundsMax\":[%.2f,%.2f,%.2f]}",
               j?",":"",c->id,safe,c->score,c->nearDist,c->centerDist,
               c->halfDiag,c->lightDist,c->linked?"true":"false",
               c->seenDraws,c->skippedDraws,
               c->lower[0],c->lower[1],c->lower[2],
               c->upper[0],c->upper[1],c->upper[2]);
        }
        DWV4Append(&out,&remaining,"]}");
    }
    DWV4Append(&out,&remaining,
       "\n],\"limitations\":\"Candidate ranking is spatial/material heuristic; only fixed-camera A/B/A can establish causal shadow contribution. Does not prove physical fixture association or depth-pixel owner.\"\n}\n");
    snprintf(filename,sizeof(filename),"dw_ps_v4_%s_mode%d.json",tr.world->baseName,mode);
    ri.FS_WriteFile(filename,buf,(int)strlen(buf));
    free(buf);
    if(mode==0){
        if(best>=0){dwV4Source_t *src=&dwV4Sources[best];
            snprintf(selection,sizeof(selection),
              "// Auto-generated for this map by V4 baseline. Single-source only.\n"
              "set r_dwPointV4FocusMap \"%s\"\n"
              "set r_dwPointV4FocusX \"%.4f\"\n"
              "set r_dwPointV4FocusY \"%.4f\"\n"
              "set r_dwPointV4FocusZ \"%.4f\"\n"
              "set r_dwPointV4FocusId1 \"%d\"\n"
              "set r_dwPointV4FocusId2 \"%d\"\n"
              "set r_dwPointV4FocusId3 \"%d\"\n"
              "set r_dwPointV4FocusLinked \"%d\"\n",
              tr.world->baseName,src->capture[0],src->capture[1],src->capture[2],
              idx1,idx2,idx3,linked);
        }else{
            snprintf(selection,sizeof(selection),
              "// No source with a submitted BSP candidate. Fail open.\n"
              "set r_dwPointV4FocusMap \"%s\"\n"
              "set r_dwPointV4FocusId1 \"-1\"\n"
              "set r_dwPointV4FocusId2 \"-1\"\n"
              "set r_dwPointV4FocusId3 \"-1\"\n"
              "set r_dwPointV4FocusLinked \"0\"\n",tr.world->baseName);
            if(!dwV4WarnedNoCandidate++)
              ri.Printf(PRINT_WARNING,"DW_PS_V4_NO_AUTOMATIC_SOURCE: no eligible submitted geometry; preserve all shadows\n");
        }
        ri.FS_WriteFile("DW_PS_V4_SELECTION.cfg",selection,(int)strlen(selection));
        ri.Printf(PRINT_ALL,"DW_PS_V4_SELECTION map=%s sourceIndex=%d selectedIDs=%d,%d,%d emitterLinked=%d (heuristic only)\n",
           tr.world->baseName,best,idx1,idx2,idx3,linked);
    }
    ri.Printf(PRINT_ALL,"DW_PS_V4_REPORT_OK file=%s mode=%d sources=%d skippedOnlySelectedPointCapture=1\n",
              filename,mode,dwV4SourceCount);
}
'''

def apply(root, check=False, proof=None):
    base=Path(root)/'SP/code/rend2'
    prev={name:(base/name).read_text(encoding='utf-8') for name in EXPECTED}
    for name,contents in prev.items():
        assert sha(contents)==EXPECTED[name],('V32 source hash changed; FAIL CLOSED',name,sha(contents))
        assert MARK not in contents,('V4 already installed',name)
    assert 'DARKWOLF_POINT_V32_BOSS1_SOURCE_LOCAL_SELFSHADOW_GUARD_41019985033' in prev['tr_backend.c']
    assert 'DARKWOLF_SUN_HDR16F_PRECISION_V1_40878732886' in prev['tr_backend.c']
    new=dict(prev)
    target='extern cvar_t  *r_dwPointV32FixtureGuard; // DARKWOLF_POINT_V32_BOSS1_SOURCE_LOCAL_SELFSHADOW_GUARD_41019985033'
    new['tr_local.h']=replace_once(new['tr_local.h'],target,target+'\n'+''.join(f'extern cvar_t  *{name}; // {MARK}\n' for name,*_ in NAMES),'externs')
    target='cvar_t  *r_dwPointV32FixtureGuard; // DARKWOLF_POINT_V32_BOSS1_SOURCE_LOCAL_SELFSHADOW_GUARD_41019985033'
    new['tr_init.c']=replace_once(new['tr_init.c'],target,target+'\n'+''.join(f'cvar_t  *{name}; // {MARK}\n' for name,*_ in NAMES),'definitions')
    target='\tri.Cvar_CheckRange( r_dwPointV32FixtureGuard, 0, 1, qtrue );'
    registers='\n\t// '+MARK+': TEST only, safe defaults OFF.\n'
    for name,default,flags,lo,hi,integer in NAMES:
        registers+=f'\t{name} = ri.Cvar_Get( "{name}", "{default}", {flags} );\n'
        if lo is not None:
            registers+=f'\tri.Cvar_CheckRange( {name}, {lo}, {hi}, {"qtrue" if integer else "qfalse"} );\n'
    new['tr_init.c']=replace_once(new['tr_init.c'],target,target+registers,'registrations')
    backend=new['tr_backend.c']
    backend=replace_once(backend,'static qboolean DWPointV32SkipProvenFixtureCaster(const drawSurf_t *ds)',
         C_CODE+'\nstatic qboolean DWPointV32SkipProvenFixtureCaster(const drawSurf_t *ds)','code helpers')
    loop='\tfor (i = 0, drawSurf = drawSurfs ; i < numDrawSurfs ; i++, drawSurf++) {\n'
    backend=replace_once(backend,loop,loop+
        '\t\tif(i==0 && DWV4Enabled())DWV4BeginPass(); // '+MARK+'\n'+
        '\t\tif(DWV4InspectAndMaybeSkip(drawSurf))continue;\n','draw loop')
    finish='\t// go back to the world modelview matrix\n\tbackEnd.currentEntity = &tr.worldEntity;'
    backend=replace_once(backend,finish,'\tif(DWV4Enabled())DWV4WriteDiagnostics();\n'+finish,'end draw')
    new['tr_backend.c']=backend
    assert 'DWV4BestSource' in backend and 'DWV4InspectAndMaybeSkip(drawSurf)' in backend
    assert 'DARKWOLF_STAGE11_UNIFIED_ASSET_SHADOW_COVERAGE_CLEAN_PRODUCTION_V1' in backend
    if not check:
        for name,contents in new.items(): (base/name).write_text(contents,encoding='utf-8')
    payload={
        'type':'DARKWOLF_V4_UNIVERSAL_DIAGNOSTIC_RELEASE_1_OF_2',
        'accepted_production_run':41019985033,
        'source_parent':'V32 source-local test on clean 41019985033',
        'marker':MARK,'check_only':check,
        'modified_files':['SP/code/rend2/'+f for f in EXPECTED],
        'sha256_before':{f:sha(x) for f,x in prev.items()},
        'sha256_after':{f:sha(x) for f,x in new.items()},
        'safe_defaults':{'r_dwPointV4Scan':0,'r_dwPointV4Mode':0,'r_dwPointV32FixtureGuard':0},
        'one_exec_auto_selection':True,
        'one_source_one_map_only':True,
        'global_material_removal':False,
        'caster_receiver_stage11_preserved_at_defaults':True,
        'other_lights_fire_tesla_sun_and_world_visibility_unchanged_by_v4':True,
        'user_gpu_validation':'PENDING',
        'limitations':'BSP emitter association is heuristic; per-map A/B screenshot proof required; only available ordinary point-shadow captures are scanned.'
    }
    if proof:
        p=Path(proof);p.parent.mkdir(parents=True,exist_ok=True)
        p.write_text(json.dumps(payload,indent=2)+'\n',encoding='utf-8')
    print('DW_PS_V4_UNIVERSAL_DIAGNOSTIC_SOURCE_PASS')
    return payload

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('root',type=Path)
    parser.add_argument('--check-only',action='store_true')
    parser.add_argument('--proof',type=Path)
    args=parser.parse_args()
    apply(args.root,check=args.check_only,proof=args.proof)
